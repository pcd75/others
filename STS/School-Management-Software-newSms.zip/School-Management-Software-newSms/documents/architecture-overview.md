# ARCHITECTURE SMS BACKEND

# Overview
![ApplicationInteraction](../documents/imgs/ApplicationInteraction.JPG)
TODO small aber smart explaning
## WebApi VS. Web App
![WebApiAdvantage.JPG](../documents/imgs/WebApiAdvantage.JPG)
TODO@Idrice small aber smart explaning
Best pro: 1, 2 and 3 can be implemented with different Technologie or Platform without changing server implementation.!!