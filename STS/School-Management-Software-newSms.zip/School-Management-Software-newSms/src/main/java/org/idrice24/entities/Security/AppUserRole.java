package org.idrice24.entities.Security;

public enum AppUserRole {
    USER,
    ADMIN,
    STUDENT,
    PARENT
}
