package org.idrice24;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Idrice24ApplicationTests {

	@Test
	void contextLoads() {
	}

}
