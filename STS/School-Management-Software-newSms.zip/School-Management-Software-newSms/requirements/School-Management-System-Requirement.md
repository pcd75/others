REQUIREMENT

# Intro


# Concept

## Goals

## Stackholders


# Fonctional requiremmnts

## Home

## Contacts

## Login

## Registry
---

## About us

## Admin

## Modules
###  School 
--
--
### 

# Non Fonctional requirements
## Security
## Disponibility
## Maintainable
## Extensibility
## Domaine name

## Colors
1. Primary Color
1. Secondary Color

## Languages
1. English
1. French

# Example of platforms
1.    xx
1.    yy

# Milestones
The following should be on prototyp oder first release
1. Home page
1. Login page
1. School page
1. Registry page
1. Student  page
