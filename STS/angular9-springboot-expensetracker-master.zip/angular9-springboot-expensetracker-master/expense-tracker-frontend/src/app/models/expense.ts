export class Expense {
    id: number;
    expense: string;
    amount: number;
    description: string;
}
