package org.idrice24.controllers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class DownloadFileController {
    
}
