package org.idrice24.services;

public enum AppUserRole {
    USER,
    ADMIN
}
