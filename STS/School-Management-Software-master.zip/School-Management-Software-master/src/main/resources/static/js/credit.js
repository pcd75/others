var cre = document.getElementById("marks").value;
var out = 0;
var arr1 = ["CALCULUS", "ELECTRONICS", "ALGORITHMS", "ALGEBRA", "LITERACY", "ECONOMICS", "ENGLISH", "ACCOUNTING", "FRENCH", "SOFTWARE ENGINEERING", "CIRCUIT THEORY", "PROBABILITY", "STATETICS", "WEP PROGRAMMING", "OPERATING SYSTEM", "COMPUTER ARCHITECTURE", "PROGRAMMING", "DATABASE AND MERISE"];
var arr2 = [""]
var cou = document.getElementById("course").value;

function credit() {
    for (var i = 0; i < arr1.length; i++) {
        if (arr[i] == cou) {

        }
    }

    if (cre <= 10) {
        return out;
    } else {
        return good;
    }
}